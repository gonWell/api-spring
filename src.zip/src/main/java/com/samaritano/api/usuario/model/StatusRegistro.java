package com.samaritano.api.usuario.model;

public enum StatusRegistro {
    ATIVO,
    REMOVIDO
}
